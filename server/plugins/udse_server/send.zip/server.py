# -*- coding: utf-8 -*-

import SimpleXMLRPCServer
import xmlrpclib
import psycopg2
import json

class DB(object):
    def connect(self):
        self.con = psycopg2.connect('dbname=%s user=%s host=%s password=%s' % (
            config['dbName'],
            config['dbUser'],
            config['dbHost'],
            config['dbPassword']))
        return self.con

def ping():
    return True

def infType(dataType):
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if dataType == '':
            cursor.execute("SELECT TABLE_NAME FROM %s.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'public'"%(config['dbName']))
            fetch = cursor.fetchall()
            if len(fetch) == 0:
                result = False, 'Типы отсутстуют.'
            else:
                result = {}
                for row in fetch:
                    cursor.execute("SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '%s' AND COLUMN_NAME = 'data'"%(row[0]))
                    dbType = cursor.fetchone()[0]
                    result[row[0]] = dbType
                result = True, json.dumps(result)
        else:
            cursor.execute("SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '%s' AND COLUMN_NAME = 'data'"%(dataType))
            fetch = cursor.fetchone()
            if fetch is None:
                result = False, 'Тип "%s" не существует.'%(dataType)
            else:
                result = True, fetch[0]
    except psycopg2.DatabaseError, error:
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def addType(dataType, auth):
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if dataType in reservedTypes:
            result = False, 'Тип "%s" зарезервирован.'%(dataType)
        else:
            if dataType in relativeTypes.keys():
                cursor.execute("CREATE TABLE %s(id VARCHAR PRIMARY KEY, data JSON)"%(dataType))
                for row in relativeTypes[dataType]:
                    cursor.execute("CREATE TABLE %s(id VARCHAR PRIMARY KEY, data JSON)"%(row))
            elif dataType == 'file':
                cursor.execute("CREATE TABLE %s(id SERIAL PRIMARY KEY, data BYTEA)"%(dataType))
            else:
                cursor.execute("CREATE TABLE %s(id SERIAL PRIMARY KEY, data JSON)"%(dataType))
            connection.commit();
            result = True, 'Тип "%s" добавлен.'%(dataType)
    except psycopg2.DatabaseError, error:
        if connection:
            connection.rollback()
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def delType(dataType, auth):
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if dataType in reservedTypes:
            result = False, 'Тип "%s" защищён от изменения напрямую.'%(dataType)
        else:
            cursor.execute("DROP TABLE %s"%(dataType))
            if dataType in relativeTypes.keys():
                for row in relativeTypes[dataType]:
                    cursor.execute("DROP TABLE %s"%(row))
            connection.commit();
            result = True, 'Тип "%s" удалён.'%(dataType)
    except psycopg2.DatabaseError, error:
        if connection:
            connection.rollback()
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def addData(dataType, dataID, data, auth):
    #auth = 'admin:password' # на потом - авторизация + LDAP
    if dataType == 'file':
        data = psycopg2.Binary(data.data)
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if dataType in relativeTypes.keys():
            if dataID == '':
                result = False, 'ID данного типа не может быть пустым.'
            else:
                cursor.execute("INSERT INTO %s (id, data) VALUES ('%s', '%s') RETURNING id"%(dataType, dataID, data))
                result = True, cursor.fetchall()[0][0]
                for row in relativeTypes[dataType]:
                    cursor.execute("INSERT INTO %s (id) VALUES ('%s')"%(row, result[1]))
        else:
            cursor.execute("INSERT INTO %s (data) VALUES (%s) RETURNING id"%(dataType, data))
            result = True, cursor.fetchall()[0][0]
        connection.commit();
    except psycopg2.DatabaseError, error:
        if connection:
            connection.rollback()
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def getData(dataType, dataID, auth):
    #auth = 'admin:password' # на потом - авторизация + LDAP
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if (dataID == 'all' and dataType != 'file'):
            cursor.execute("SELECT * FROM %s"%(dataType))
            fetch = cursor.fetchall()
            if len(fetch) == 0:
                result = False, 'Таблица "%s" пустая!'%(dataType)
            else:
                if isinstance(fetch[0][1], str) and (infType(dataType)[1] == 'json'):
                    result=[]
                    for row in fetch:
                        result.append([row[0],json.loads(row[1])])
                    result = True, json.dumps(result)
                else:
                    result = True, json.dumps(fetch)
        else:
            cursor.execute("SELECT data FROM %s WHERE id='%s'"%(dataType, dataID))
            fetch = cursor.fetchone()
            if fetch is None:
                result = False, 'Элемента c ID="%s" типа "%s" не существует!'%(dataID, dataType)
            elif fetch[0] is None:
                result = False, 'Элемент c ID="%s" типа "%s" пустой!'%(dataID, dataType)
            else:
                if (infType(dataType)[1] == 'bytea'):
                    result = True, xmlrpclib.Binary(fetch[0])
                elif (not isinstance(fetch[0], str)) and (infType(dataType)[1] == 'json'):
                    result = True, json.dumps(fetch[0])
                else:
                    result = True, fetch[0]
    except psycopg2.DatabaseError, error:
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def setData(dataType, dataID, data, auth):
    #auth = 'admin:password' # на потом - авторизация + LDAP
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        cursor.execute("UPDATE %s SET data = '%s' WHERE id = '%s' RETURNING id"%(dataType, data, dataID))
        result = True, len(cursor.fetchall())
        connection.commit();
    except psycopg2.DatabaseError, error:
        if connection:
            connection.rollback()
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def delData(dataType, dataID, auth):
    #auth = 'admin:password' # на потом - авторизация + LDAP
    try:    
        connection = DB().connect()
        cursor = connection.cursor()
        if dataID == 'all':
            cursor.execute("DELETE FROM %s RETURNING id"%(dataType))
        else:
            cursor.execute("DELETE FROM %s WHERE id = '%s' RETURNING id"%(dataType, dataID))
        fetch = cursor.fetchall()
        if dataType in relativeTypes.keys():
            for row in fetch:
                dataID = row[0]
                for row in relativeTypes[dataType]:
                    cursor.execute("DELETE FROM %s WHERE id = '%s'"%(row, dataID))
        connection.commit();
        if len(fetch) > 0:
            result = True, len(fetch)
        else:
            result = False, 'Ничего не было удалено.'
    except psycopg2.DatabaseError, error:
        if connection:
            connection.rollback()
        print error
        result = False, str(error)
    finally:
        connection.close()
    return result

def main():
    server = SimpleXMLRPCServer.SimpleXMLRPCServer((config['srvIP'], config['srvPort']))
    server.register_function(ping)
    server.register_function(infType)
    server.register_function(addType)
    server.register_function(delType)
    server.register_function(getData)
    server.register_function(setData)
    server.register_function(addData)
    server.register_function(delData)
    server.serve_forever()

if __name__ == '__main__':
    with open('config.json') as file:
        config = json.load(file)
        relativeTypes = config['relativeTypes']
    reservedTypes=[]
    for reservedType in relativeTypes.values():
        reservedTypes.extend(reservedType)
    main()
